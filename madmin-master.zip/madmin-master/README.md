# Madmin 🎫 


[![Website](https://img.shields.io/badge/site-up%20and%20running-lightgrey.svg)](https://majhirockzz.github.io/Materialize-CSS-Project-3/)
[![GitHub](https://img.shields.io/github/license/mashape/apistatus.svg)](https://github.com/MajhiRockzZ/Materialize-CSS-Project-3/blob/master/LICENSE)
[![GitHub repo size in bytes](https://img.shields.io/badge/repo%20size-1.32%20MB-blue.svg)](https://github.com/MajhiRockzZ/Materialize-CSS-Project-3/)
[![Github commit merge status](https://img.shields.io/github/commit-status/badges/shields/master/5d4ab86b1b5ddfb3c4a70a70bd19932c52603b8c.svg)](https://github.com/MajhiRockzZ/Materialize-CSS-Project-3/)

## Info
Materialize CSS Admin Dashboard Templates.

## Features  

- Google **material** design.
- **Side** nav bar.
- HTML5 JavaScript Chart using **CanvasJS**
- Smart editor using **CKEditor**.
- **Responsive** design.

## Author

[Sumesh Majhi](https://github.com/MajhiRockzZ)
